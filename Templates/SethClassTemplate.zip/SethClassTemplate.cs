﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $rootnamespace$
{
    public class $safeitemname$
    {
        // ---------------- Fields ----------------

        // ---------------- Constructor ----------------

        public $safeitemname$()
        {
        }

        // ---------------- Properties ----------------

        // ---------------- Functions ----------------
    }
}
