﻿using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;

namespace $rootnamespace$
{
    [TestFixture]
    public class $safeitemname$
    {
        // ---------------- Fields ----------------

        // ---------------- Setup / Teardown ----------------

        [TestFixtureSetUp]
        public void FixtureSetup()
        {

        }

        [TestFixtureTearDown]
        public void FixtureTeardown()
        {
        }

        [SetUp]
        public void TestSetup()
        {
        }

        [TearDown]
        public void TestTeardown()
        {
        }

        // ---------------- Tests ----------------

        // ---------------- Test Helpers ----------------
    }
}
